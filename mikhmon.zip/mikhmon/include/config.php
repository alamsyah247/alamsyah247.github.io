<?php 
if(substr($_SERVER["REQUEST_URI"], -10) == "config.php"){header("Location:./");}; 
$data['mikhmon'] = array ('1'=>'mikhmon<|<mikhmon','mikhmon>|>aWNlbA==');

$data['BarokahHotspot'] = array ('1'=>'BarokahHotspot!remote2.vpnmurahjogja.my.id:3234','BarokahHotspot@|@admin','BarokahHotspot#|#pZKVamVibw==','BarokahHotspot%Warung Barokah','BarokahHotspot^barokah.wrg','BarokahHotspot&Rp','BarokahHotspot*10','BarokahHotspot(3','BarokahHotspot)','BarokahHotspot=10','BarokahHotspot@!@enable');